# logdoc/errors/__init__.py
