# logdoc/utils/__init__.py
